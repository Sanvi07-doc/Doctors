let mediaRecorder;
let audioChunks = [];
let transcriptionArea = document.getElementById('transcription');
let audioElement = document.getElementById('audioPlayback');

const startRecordBtn = document.getElementById('startRecordBtn');
const stopRecordBtn = document.getElementById('stopRecordBtn');
const statusElement = document.getElementById('status');

// Request microphone access
navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = event => {
        audioChunks.push(event.data);
    };

    mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const audioUrl = URL.createObjectURL(audioBlob);
        audioElement.src = audioUrl;
        audioChunks = [];

        // Send the audio blob to the server for transcription
        sendAudioToServer(audioBlob);
    };
});

startRecordBtn.addEventListener('click', () => {
    mediaRecorder.start();
    statusElement.textContent = 'Recording Status: Recording...';
    startRecordBtn.disabled = true;
    stopRecordBtn.disabled = false;
});

stopRecordBtn.addEventListener('click', () => {
    mediaRecorder.stop();
    statusElement.textContent = 'Recording Status: Not Recording';
    startRecordBtn.disabled = false;
    stopRecordBtn.disabled = true;
});

function sendAudioToServer(audioBlob) {
    const formData = new FormData();
    formData.append('audio', audioBlob);

    fetch('/transcribe', {
        method: 'POST',
        body: formData
    }).then(response => response.json())
    .then(data => {
        transcriptionArea.value = data.transcript;
    }).catch(err => console.error(err));
}
